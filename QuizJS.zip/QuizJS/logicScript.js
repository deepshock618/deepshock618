console.log("start");




// fetch('./questions.json')
// .then(function (response){
//     return response.json();
// })
// .then(function (data)
// {
//     


//     
    
    
//    this.q=JSON.parse(data);
//     console.log(typeof(data));
//     console.log(data.questions[0]);
// });

// console.log(q.questions);

let q={
    "questions":[   {   qn:"What is the fullform of JSON?",
                        a:"JavaScript Object Numeral",
                        b:"JavaScript Object Notation",
                        c:"JavaScript Objective Numeral",
                        id:0
                     },

                    {   qn:"What is the full form of HTML?",
                        a:"Hypertext Marking Language",
                        b:"Hyphenated Markup Language",
                        c:"Hypertext Markup Language",
                        id:1
                     },
                    {   qn:"What is the fullform of SQL?",
                        a:"Simple Query Language",
                        b:"Structured Query Language",
                        c:"Simple Quotient Language",
                        id:2
                    },
                    {   qn:"What is more secure method Post or Get?",
                        a:"Post",
                        b:"Get",
                        c:"Both are same",
                        id:3
                    }  
                ]
};
let a={
            "solutions":[  {    qn:"What is the fullform of JSON?",
                                a:"JavaScript Object Numeral",
                                b:"JavaScript Object Notation",
                                c:"JavaScript Objective Numeral",
                                id:0,
                                ans:"JavaScript Object Notation"
                            },

                            {   qn:"What is the full form of HTML?",
                                a:"Hypertext Marking Language",
                                b:"Hyphenated Markup Language",
                                c:"Hypertext Markup Language",
                                id:1,
                                ans:"Hypertext Markup Language"

                            },
                            {   qn:"What is the fullform of SQL?",
                                a:"Simple Query Language",
                                b:"Structured Query Language",
                                c:"Simple Quotient Language",
                                id:2,
                                ans:"Structured Query Language"
                            },
                            {   qn:"What is more secure method Post or Get?",
                                a:"Post",
                                b:"Get",
                                c:"Both are same",
                                id:3,
                                ans:"Post" 
                            }   
                        ]
        };


        

            function bindQuestions(question)
            {
                
                return `
                <div>
                <label for="question${question.id}">${question.qn}</label>
                <input type="radio" name="${question.id}" value="${question.a}" id="a${question.id}" >${question.a}</input>
                <input type="radio" name="${question.id}" value="${question.b}" id="b${question.id}" >${question.b}</input>
                <input type="radio" name="${question.id}" value="${question.c}" id="c${question.id}" >${question.c}</input>
                </div><br>
                `;
            }
            
            document.querySelector("form").innerHTML=`<h2>The questions are</h2>${q.questions.map(bindQuestions).join('')}
            <div><button onclick="score()" type="submit" id="btn1">Submit</button></div>`;


            let sc=0;


            function score()
            {   
                let radios=document.querySelectorAll('input');
                let checkedAnswers=[];
                for(let j=0;j<radios.length;j++)
                {
                    if(radios[j].checked)
                        checkedAnswers.push(radios[j].value);
                }
                
                for(let i=0;i<a.solutions.length;i++)
                {
                    if(a.solutions[i].ans==checkedAnswers[i])
                        sc++;
                }

                // return sc;
            }

        
            function bindAnswers(answer)
            {
                return `
                <div>
                <p>Question:${answer.qn}</p>
                <p>Answer:${answer.ans}</p>
                </div>
                <br>
                `;
            }
            const form=document.querySelector('form');
            form.addEventListener('submit', evt=>
            {
                evt.preventDefault();
                document.querySelector("#answers").innerHTML=`
                <h2>Results:</h2>
                <div>Score:${sc}</div>
                ${a.solutions.map(bindAnswers).join('')}`;
            })