package com.proto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Shoe {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String sname;
	private String scolor;
	private String category;
	
	
	public Shoe() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getScolor() {
		return scolor;
	}
	public void setScolor(String scolor) {
		this.scolor = scolor;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Shoe(int id, String sname, String scolor, String category) {
		super();
		this.id = id;
		this.sname = sname;
		this.scolor = scolor;
		this.category = category;
	}
	@Override
	public String toString() {
		return "Shoe [id=" + id + ", sname=" + sname + ", scolor=" + scolor + ", category=" + category + "]";
	}
}
