package com.proto;

public interface AdminService {
	void saveAdmin(Admin admin);
	Admin getById(int id);
}
