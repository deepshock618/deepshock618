package com.proto;


public interface ShoeService {
	Iterable<Shoe> getAllShoes();
	void saveShoe(Shoe shoe);
	void deleteShoeById(int id);
	Shoe getById(int id);
	
}
