package com.proto;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ShoeDao implements ShoeService {
	
	@Autowired
	private ShoeRepository sr;

	@Override
	public Iterable<Shoe> getAllShoes() {
			
		return sr.findAll();
	}
	@Override
	public Shoe getById(int id)
	{
		Optional<Shoe>optional=sr.findById(id);
		Shoe shoe=optional.get();
		return shoe;
		
	}

	@Override
	public void saveShoe(Shoe shoe) {

		sr.save(shoe);
		
	}

	@Override
	public void deleteShoeById(int id) {
		
		sr.deleteById(id);
		
	}
	
}
