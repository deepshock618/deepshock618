package com.proto;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class ShoePurchase {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int id;
	@Column
	String sname;
	@Column
	String category;
	@Column
	String date;
	public ShoePurchase() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ShoePurchase(int id, String sname, String category, String date) {
		super();
		this.id = id;
		this.sname = sname;
		this.category = category;
		this.date = date;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "ShoePurchase [id=" + id + ", sname=" + sname + ", category=" + category + ", date=" + date + "]";
	}
	
	
}
