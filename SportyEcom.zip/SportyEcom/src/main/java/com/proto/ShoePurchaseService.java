package com.proto;


import java.util.List;

public interface ShoePurchaseService {
	Iterable<ShoePurchase> getAllShoePurchases();
	void saveShoePurchase(ShoePurchase shoePurchase);
	List<ShoePurchase> showShoePurchaseByCategory(String category);
	List<ShoePurchase> showShoePurchaseByDate(String date);
}
