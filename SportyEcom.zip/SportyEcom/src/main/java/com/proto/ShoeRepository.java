package com.proto;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ShoeRepository  extends CrudRepository<Shoe,Integer>{
	//public List<Shoe> findByName(String sname);

}
