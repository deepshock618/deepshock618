package com.proto;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminPortController {
	@Autowired
	UserDao ud;
	@Autowired
	ShoeDao sd;
	@Autowired
	AdminDao ad;
	@Autowired
	ShoePurchaseDao spd;
	
	@RequestMapping("/allPurchases")
	public String allPurchases(Model m)
	{
		Iterable<ShoePurchase> purchases=spd.getAllShoePurchases();
		m.addAttribute("purchases", purchases);
		return "/allPurchases";
	}
	@RequestMapping("/purchaseByCategory")
	public String purchaseByCategory(@RequestParam String category, Model m)
	{
		List<ShoePurchase> purchases=spd.showShoePurchaseByCategory(category);
		m.addAttribute("purchases", purchases);
		return "/purchaseByCategory";
	}

	@RequestMapping("/purchaseByDate")
	public String purchaseByDate(@RequestParam String date, Model m)
	{
		List<ShoePurchase> purchases=spd.showShoePurchaseByDate(date);
		m.addAttribute("purchases", purchases);
		return "/purchaseByDate";
	}
	@RequestMapping("/userByName")
	public String userByName(@RequestParam String name, Model m )
	{
		List<User> un=ud.getUserByName(name);
		m.addAttribute("users", un);
		m.addAttribute("name", name);
		
		return "/userByName";
	}
	@RequestMapping("/userList")
	public String userList(Model m)
	{	
		Iterable<User> users=ud.getAllUsers();
		m.addAttribute("users", users);
		
		return "/userList";
	}
	@RequestMapping(path="/adminPass", method=RequestMethod.POST)
	public String adminPass(@ModelAttribute Admin admin)
	{	
		this.ad.saveAdmin(admin);
		return "/adminPass";
	}
	@RequestMapping("/manageProducts")
	public String manage()
	{
		
		return "/manageProducts";
	}
	@RequestMapping("/shoeList")
	public String shoeList(Model m)
	{
		Iterable<Shoe> s1=sd.getAllShoes();
		m.addAttribute("shoes",s1);
		
		return "/shoeList";
	}
	@RequestMapping("/addShoe")
	public String addShoe(@ModelAttribute Shoe shoe, Model m)
	{
		this.sd.saveShoe(shoe);
		return "/productChange";
	}
	@RequestMapping("/deleteShoe")
	public String deleteShoe(@RequestParam int id, Model m)
	{
		this.sd.deleteShoeById(id);
		return "/productChange";
	}
	@RequestMapping("/logoutAdmin")
	public String logoutAdmin(HttpServletRequest req, HttpServletResponse res)
	{	
		HttpSession  session=req.getSession();
		session.removeAttribute("identifierAP");
		session.invalidate();
		//res.sendRedirect("index.jsp");
		
		return "index";
	}
}
