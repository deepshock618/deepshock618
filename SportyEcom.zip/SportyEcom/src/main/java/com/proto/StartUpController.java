package com.proto;





import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import net.bytebuddy.dynamic.DynamicType.Builder.FieldDefinition.Optional;

@Controller
public class StartUpController {
	
	@Autowired
	UserDao ud1;
	@Autowired
	ShoePurchaseDao spd1;
	@Autowired
	ShoeDao sd1;
	@Autowired
	AdminDao ad1;
	
	
	@RequestMapping("/")
	public String startUp()
	{
		return "index";
	}
	
	@RequestMapping("/signUp")
	public String signUp()
	{
		
		return "/signUp";
	}
	@RequestMapping(path="/signUpSuccess", method=RequestMethod.POST)
	public String signUpSuccess(@ModelAttribute User user, Model model)
	{
		this.ud1.saveUser(user);
		model.addAttribute("User",user);
		System.out.println(user);
		return "/signUpSuccess";
	}
	@RequestMapping(path="/sportyShoesHome", method=RequestMethod.POST)
	public String home(Model m, @RequestParam int id, @RequestParam String password, HttpServletRequest req, HttpServletResponse res)
	{
		User user=ud1.getById(id);
		String pass1=user.getPassword();
		
		if(pass1.equals(password))
			{Iterable<Shoe> shoes=sd1.getAllShoes();
			m.addAttribute("shoes", shoes);
			
			HttpSession session=req.getSession();
			session.setAttribute("identifier", user.getId());
			
			
			return "/sportyShoesHome";}
		
		else
			{return "/";}
		
	}
	
	@RequestMapping("/purchase")
	public String purchase(@RequestParam int id, @RequestParam String date)
	{	
		
		Shoe sh=sd1.getById(id);
		
		ShoePurchase sp=new ShoePurchase();
		sp.setSname(sh.getSname());
		sp.setCategory(sh.getCategory());
		sp.setDate(date);
		
		spd1.saveShoePurchase(sp);
		
		return "/purchase";
	}
	@RequestMapping("/adminLogin")
	public String adminLogIn()
	{
		
		return "/adminLogin";
	}
	@RequestMapping(path="/adminPortal", method=RequestMethod.POST)
	public String adminPortal(@RequestParam String password, HttpServletRequest req,HttpServletResponse res)
	{
		Admin admin=ad1.getById(1);
		String pass=admin.getPassword();
		if(pass.equals(password))
		{
			HttpSession session=req.getSession();
			session.setAttribute("identifierAP", admin.getPassword());
		
			return "/adminPortal";
		}
		else
			{return "/";
			}
	}
	@RequestMapping("/logoutUser")
	public String logoutAdmin(HttpServletRequest req, HttpServletResponse res)
	{	
		HttpSession  session=req.getSession();
		session.removeAttribute("identifier");
		session.invalidate();
		//res.sendRedirect("index.jsp");
		
		return "index";
	}
}
