package com.proto;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ShoePurchaseDao implements ShoePurchaseService {

	
	@Autowired
	ShoePurchaseRepository spr;

	@Override
	public Iterable<ShoePurchase> getAllShoePurchases() {
		
		return spr.findAll();
	}

	@Override
	public void saveShoePurchase(ShoePurchase shoePurchase) {
		
		spr.save(shoePurchase);
		
	}
	
	


	@Override
	public List<ShoePurchase> showShoePurchaseByCategory(String category) 
	{
		
		return spr.findByCategory(category);
		
	}

	@Override
	public List<ShoePurchase> showShoePurchaseByDate(String date) {
		
		return spr.findByDate(date);
	}
	
	
}
