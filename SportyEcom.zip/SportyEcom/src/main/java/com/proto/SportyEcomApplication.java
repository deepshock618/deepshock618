package com.proto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportyEcomApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportyEcomApplication.class, args);
	}

}
