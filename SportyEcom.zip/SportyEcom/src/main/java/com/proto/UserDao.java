package com.proto;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;


@Component
public class UserDao implements UserService {
		
	@Autowired
	private UserRepository ur;
	
	@Override
	public void saveUser(User user)
	{
		ur.save(user);
	}
	
	@Override
	public List<User> getUserByName(String name){
		return ur.findByName(name);
	}
	@Override
	public User getById(int id)
	{
		Optional<User>optional=ur.findById(id);
		User user=optional.get();
		return user;
	}

	@Override
	public Iterable<User> getAllUsers() {
		
		return ur.findAll();
	}
	
	
}
