package com.proto;

import java.util.List;

public interface UserService {
	Iterable<User> getAllUsers();
	List<User> getUserByName(String name);
	void saveUser(User user);
	User getById(int id);
}
