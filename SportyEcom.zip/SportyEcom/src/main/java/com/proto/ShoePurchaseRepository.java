package com.proto;


import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ShoePurchaseRepository extends CrudRepository<ShoePurchase,Integer>{

	public List<ShoePurchase> findByCategory(String Category);
	public List<ShoePurchase> findByDate(String date);
}
