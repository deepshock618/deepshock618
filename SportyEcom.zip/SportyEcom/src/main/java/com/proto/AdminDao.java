package com.proto;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AdminDao implements AdminService {

	@Autowired
	AdminRepository ar;

	@Override
	public void saveAdmin(Admin admin) {
		admin.setId(1);
		ar.save(admin);
		
	}
	
	@Override
	public Admin getById(int id)
	{
		Optional<Admin>optional=ar.findById(id);
		Admin admin=optional.get();
		return admin;
	}
	
	

	
}
