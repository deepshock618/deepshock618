import java.util.Set;
import java.util.concurrent.TimeUnit;

import java.util.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LogInTest {
	WebDriver driver=null;
	String email="dummyarka001@gmail.com";
	String password="arka0000";
	String product="iphone xr";
	String message;
	@BeforeTest
	public void setUp() {
		
		WebDriverManager.chromedriver().setup();
		driver =new ChromeDriver();
		System.out.println("Starting test");
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void signUp() {
		System.out.println("Loging in");
		driver.get("http://amazon.in");
		
		driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']")).click();
		
		
		try{
		driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys(email);
		driver.findElement(By.xpath("//input[@id='continue']")).click();
		
		
		driver.findElement(By.xpath("//input[@id='ap_password']")).sendKeys(password);
		driver.findElement(By.xpath("//input[@id='signInSubmit']")).click();
		
		
		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys(product);
		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys(Keys.RETURN);
		
		
		driver.findElement(By.xpath("//span[text()='Apple iPhone XR (128GB) - Coral']")).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		Set<String> windowHandles=driver.getWindowHandles();
		Iterator<String> iter=windowHandles.iterator();
		String parentW=iter.next();
		String childW=iter.next();
		
		driver.switchTo().window(childW);
		
		
		driver.findElement(By.xpath("//input[@id='add-to-cart-button']")).click();
		}
		
		catch(Exception e)
		{message=driver.findElement(By.xpath("//li/span[@class='a-list-item']")).getText();
		System.out.println(message);}
		

		

			

		//driver.findElement(By.xpath("//a[text()='Go to Cart']")).click();
		
		
		
		
		
		
	}
	
//	@AfterTest
//	public void end(){
//		driver.quit();
//		System.out.println("The test is over");
//	}
}
