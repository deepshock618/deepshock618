import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SignupTest {
WebDriver driver=null;
	String name="Arkadeep";
	String email="dummyarka001@gmail.com";
	String password="arka0000";
	@BeforeTest
	public void setUp() {
		
		WebDriverManager.chromedriver().setup();
		driver =new ChromeDriver();
		System.out.println("Starting test");
	}
	
	@Test
	public void signUp() {
		System.out.println("Signing in");
		driver.get("http://amazon.in");
		
		driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']")).click();
		driver.findElement(By.xpath("//a[@id='createAccountSubmit']")).click();
		
		driver.findElement(By.xpath("//input[@id='ap_customer_name']")).sendKeys(name);
		driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys(email);
		driver.findElement(By.xpath("//input[@id='ap_password']")).sendKeys(password);
		driver.findElement(By.xpath("//input[@id='ap_password_check']")).sendKeys(password);
		
		
		driver.findElement(By.xpath("//input[@id='continue']")).click();

		
		
		
		
		
		
		
		
	}
	
//	@AfterTest
//	public void end(){
//		driver.quit();
//		System.out.println("The test is over");
//	}
}
