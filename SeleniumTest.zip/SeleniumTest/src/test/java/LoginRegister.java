import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginRegister {
	 @SuppressWarnings("deprecation")
	public static void main( String[] args ) throws InterruptedException
	    {
	        System.out.println( "Hello World! Yo!!" );
	       
	        //System.setProperty("webdriver.chrome.driver","D:/Softwares/Selenium/chromedriver.exe");
	        String name="aka";
	        String email="aka@icloud.com";
	        String password="0000";
	        String id;
	        
	        
	        WebDriverManager.chromedriver().setup();
	        
	        WebDriver driver=new ChromeDriver();
	        driver.get("http://localhost:8585");
	        
	        driver.findElement(By.xpath("//button[@id='signUp']")).click();
	        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	        driver.findElement(By.xpath("//input[@id='name']")).sendKeys(name);
	        driver.findElement(By.xpath("//input[@id='email']")).sendKeys(email);
	        driver.findElement(By.xpath("//input[@id='password']")).sendKeys(password);
	        driver.findElement(By.xpath("//button[@id='signUpConfirm']")).click();
	        id=driver.findElement(By.xpath("//input[@name='userId']")).getAttribute("value");
	        
	        //System.out.println(id);
	        
	        driver.get("http://localhost:8585");
	        driver.findElement(By.xpath("//input[@name='id']")).sendKeys(id);
	        driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
	        driver.findElement(By.xpath("//button[@id='logIn']")).click();
	    }
}
